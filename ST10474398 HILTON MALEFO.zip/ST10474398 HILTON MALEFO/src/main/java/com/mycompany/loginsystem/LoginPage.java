 package com.mycompany.loginsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class LoginPage implements ActionListener {
    JFrame frame = new JFrame();
    JButton loginButton = new JButton("Login");
    JButton resetButton = new JButton("Reset");
    JButton signUpButton = new JButton("Sign Up");
    JLabel modeLabel = new JLabel("Login Mode"); // NEW login mode

    JTextField userIDField = new JTextField();
    JPasswordField userPasswordField = new JPasswordField();
    JTextField phoneField = new JTextField();

    JLabel userIDLabel = new JLabel("User ID:");
    JLabel userPasswordLabel = new JLabel("Password:");
    JLabel phoneLabel = new JLabel("Phone (+27):");

    JLabel messageLabel = new JLabel(" ");

    HashMap<String, String> loginInfo = new HashMap<>();

    public LoginPage(HashMap<String, String> loginInfoOriginal) {
        loginInfo = loginInfoOriginal;

        //  Labels
        userIDLabel.setBounds(50, 60, 75, 25);
        userPasswordLabel.setBounds(50, 100, 75, 25);
        phoneLabel.setBounds(50, 140, 100, 25);
        messageLabel.setBounds(50, 250, 300, 35);
        messageLabel.setFont(new Font(null, Font.ITALIC, 14));
        
        modeLabel.setBounds(150, 20, 200, 25); // Position above other elements
        modeLabel.setFont(new Font(null, Font.BOLD, 16));
        frame.add(modeLabel); // Add to frame


        // this is my  Fields
        userIDField.setBounds(150, 60, 200, 25);
        userPasswordField.setBounds(150, 100, 200, 25);
        phoneField.setBounds(150, 140, 200, 25);

        //  These are my Buttons
        loginButton.setBounds(150, 180, 100, 25);
        loginButton.setFocusable(false);
        loginButton.addActionListener(this);

        resetButton.setBounds(250, 180, 100, 25);
        resetButton.addActionListener(this);

        signUpButton.setBounds(50, 180, 100, 25);
        signUpButton.setFocusable(false);
        signUpButton.addActionListener(this);

        frame.add(userIDLabel);
        frame.add(userPasswordLabel);
        frame.add(phoneLabel);
        frame.add(messageLabel);
        frame.add(userIDField);
        frame.add(userPasswordField);
        frame.add(phoneField);
        frame.add(loginButton);
        frame.add(resetButton);
        frame.add(signUpButton);

        // hide phone field
        phoneField.setVisible(false);
        phoneLabel.setVisible(false);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 350);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String userID = userIDField.getText();
        String password = String.valueOf(userPasswordField.getPassword());
        String cellNumber = phoneField.getText();

        if (e.getSource() == resetButton) {
            userIDField.setText("");
            userPasswordField.setText("");
            phoneField.setText("");
            showMessage(" ", Color.BLACK);
        }

        if (e.getSource() == loginButton) {
            // Im Hiding phone field during login
            phoneField.setVisible(false);
            phoneLabel.setVisible(false);
            
            modeLabel.setText("Login Mode"); // NEW


            if (!checkUserName(userID)) {
                showMessage("Username must have '_' and ≤ 5 chars.", Color.RED);
                return;
            }

            if (!checkPasswordComplexity(password)) {
                showMessage("<html>Password must be 8+ chars,<br>with capital, number & symbol.</html>", Color.RED);
                return;
            }

            if (loginInfo.containsKey(userID)) {
                if (loginInfo.get(userID).equals(password)) {
                    showMessage("Login successful", Color.GREEN);
                    frame.dispose();
                    new WelcomePage(userID);
                } else {
                    showMessage("Wrong password", Color.RED);
                }
            } else {
                showMessage("Username not found", Color.RED);
            }
        }

        if (e.getSource() == signUpButton) {
            
            phoneField.setVisible(true);
            phoneLabel.setVisible(true);
            
            modeLabel.setText("Sign-Up Mode"); // NEW


            if (!checkUserName(userID)) {
                showMessage("Username must have '_' and ≤ 5 chars.", Color.RED);
                return;
            }

            if (!checkPasswordComplexity(password)) {
                showMessage("<html>Password must be 8+ chars,<br>with capital, number & symbol.</html>", Color.RED);
                return;
            }

            if (!checkCellNumber(cellNumber)) {
                showMessage("Invalid phone format. Use +27 followed by 9 digits.", Color.RED);
                return;
            }

            if (loginInfo.containsKey(userID)) {
                showMessage("Username already exists.", Color.RED);
            } else {
                loginInfo.put(userID, password);
                showMessage("Sign up successful! You can now log in.", Color.GREEN);
            }
        }
    }

    
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    //  Password must be at least 8 chars, contain uppercase, digit, and symbol
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) return false;
        boolean hasUpper = false, hasDigit = false, hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }

        return hasUpper && hasDigit && hasSpecial;
    }

    // South African format +27xxxxxxxxx
    public boolean checkCellNumber(String phone) {
        return phone.matches("^\\+27\\d{9}$");
    }

    
    private void showMessage(String text, Color color) {
        messageLabel.setForeground(color);
        messageLabel.setText(text);
    }

    public static void main(String[] args) {
        HashMap<String, String> sampleLoginInfo = new HashMap<>();
        sampleLoginInfo.put("plu_9", "th&se@ke78");
        sampleLoginInfo.put("dre_7", "RtvP@ss9!");

        new LoginPage(sampleLoginInfo);
    }
}
